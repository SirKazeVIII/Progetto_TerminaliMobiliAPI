<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
		if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
		$Nome_SM = $_POST['Nome_SM'];
		$Tipo_Consumo_SM = $_POST['Tipo_Consumo_SM'];
		$Consumo_SM = $_POST['Consumo_SM'];
		$Sensore_Attivato = $_POST['Sensore_Attivato'];
		$AddOn = $_POST['AddOn'];
	
	$Sql_Query = "INSERT INTO sensori_monitoraggio (Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivato, AddOn) VALUES ('$Nome_SM', '$Tipo_Consumo_SM', '$Consumo_SM', '$Sensore_Attivato', '$AddOn')";
	
	if(mysqli_query($con, $Sql_Query)){
		
		echo 'Sensore Inserito';
	}
	else{
		echo 'Errore';
	}
	mysqli_close($con);
	?>