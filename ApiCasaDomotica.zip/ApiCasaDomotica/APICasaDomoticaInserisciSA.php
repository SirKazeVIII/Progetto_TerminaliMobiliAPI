<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
		if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
		$Nome_SA = $_POST['Nome_SA'];
		$Tipo_Consumo_SA = $_POST['Tipo_Consumo_SA'];
		$Consumo_SA = $_POST['Consumo_SA'];
		$Tempo_Attivazione = $_POST['Tempo_Attivazione'];
		$AddOn = $_POST['AddOn'];
	
	$Sql_Query = "INSERT INTO sensori_attivabili (Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_Attivazione, AddOn) VALUES ('$Nome_SA', '$Tipo_Consumo_SA', '$Consumo_SA', '$Tempo_Attivazione', '$AddOn')";
	
	if(mysqli_query($con, $Sql_Query)){
		
		echo 'Sensore Inserito';
	}
	else{
		echo 'Errore';
	}
	mysqli_close($con);
	?>