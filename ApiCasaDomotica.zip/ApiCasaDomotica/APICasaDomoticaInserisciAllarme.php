<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
		if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
		$ID_Allarme = $_POST['ID_Allarme'];
		$Data_Inizio = $_POST['Data_Inizio'];
		$Data_Fine = $_POST['Data_Fine'];

	
	$Sql_Query = "INSERT INTO allarme (ID_Allarme, Data_Inizio, Data_Fine) VALUES ('$ID_Allarme', '$Data_Inizio', '$Data_Fine')";
	
	if(mysqli_query($con, $Sql_Query)){
		
		echo 'Allarme Finito';
	}
	else{
		echo 'Errore';
	}
	mysqli_close($con);
	?>