<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
	
	$stmt = $conn->prepare("SELECT Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivato, AddOn FROM sensori_monitoraggio");
	
	$stmt->execute();
	
	$stmt->bind_result($Nome_SM, $Tipo_Consumo_SM, $Consumo_SM, $Sensore_Attivato, $AddOn);
	
	$sensori_monitoraggio = array();
	
	while($stmt->fetch()){
		
		$temp = array();
		$temp['Nome_SM']=$Nome_SM;
		$temp['Tipo_Consumo_SM']=$Tipo_Consumo_SM;
		$temp['Consumo_SM']=$Consumo_SM;
		$temp['Sensore_Attivato']=$Sensore_Attivato;
		$temp['AddOn']=$AddOn;
		
		array_push($sensori_monitoraggio, $temp);
	}
	
	echo json_encode($sensori_monitoraggio);