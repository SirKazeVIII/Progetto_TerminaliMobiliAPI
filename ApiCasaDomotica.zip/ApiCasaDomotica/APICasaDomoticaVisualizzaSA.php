<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
	
	$stmt = $conn->prepare("SELECT Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_Attivazione, AddOn FROM sensori_attivabili");
	
	$stmt->execute();
	
	$stmt->bind_result($Nome_SA, $Tipo_Consumo_SA, $Consumo_SA, $Tempo_Attivazione, $AddOn);
	
	$sensori_attivabili = array();
	
	while($stmt->fetch()){
		
		$temp = array();
		$temp['Nome_SA']=$Nome_SA;
		$temp['Tipo_Consumo_SA']=$Tipo_Consumo_SA;
		$temp['Consumo_SA']=$Consumo_SA;
		$temp['Tempo_Attivazione']=$Tempo_Attivazione;
		$temp['AddOn']=$AddOn;
		
		array_push($sensori_attivabili, $temp);
	}
	
	echo json_encode($sensori_attivabili);