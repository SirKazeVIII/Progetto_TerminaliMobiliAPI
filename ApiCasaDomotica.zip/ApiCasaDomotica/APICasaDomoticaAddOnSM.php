<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if(mysqli_connect_errno()){
	die('unable to connect to database' . mysqli_connect_error());
	}
	
	$Nome_SM = $_POST["Nome_SM"];
	$AddOn = $_POST['AddOn'];
	
	$Sql_Query = "UPDATE sensori_monitoraggio SET AddOn = '$AddOn' WHERE Nome_SM = '$Nome_SM' ";
	
		if(mysqli_query($con, $Sql_Query)){
		
		echo 'AddOn Aggiunto';
	}
	else{
		echo 'Errore';
	}
	mysqli_close($con);
	?>