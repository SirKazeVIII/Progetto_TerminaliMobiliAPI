<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if(mysqli_connect_errno()){
	die('unable to connect to database' . mysqli_connect_error());
	}
	
		$ID_Allarme = $_POST["ID_Allarme"];
		
		$Sql_Query = "DELETE FROM allarme WHERE ID_Allarme = '$ID_Allarme'";
		
	
	if(mysqli_query($con, $Sql_Query)){
		
		echo 'Allarme Eliminato';
	}
	else{
		echo 'Errore';
	}
	mysqli_close($con);
	?>