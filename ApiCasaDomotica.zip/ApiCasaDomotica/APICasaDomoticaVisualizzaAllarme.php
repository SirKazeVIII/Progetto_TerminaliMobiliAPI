<?php

	define('DB_HOST','localhost');
	define('DB_USER','root');
	define('DB_PASS', '');
	define('DB_NAME','terminali_mobili');
	
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	
	if(mysqli_connect_errno()){
		die('unable to connect to database' . mysqli_connect_error());
	}
	
	$stmt = $conn->prepare("SELECT ID_Allarme, Data_Inizio, Data_Fine FROM allarme");
	
	$stmt->execute();
	
	$stmt->bind_result($ID_Allarme, $Data_Inizio, $Data_Fine);
	
	$allarme = array();
	
	while($stmt->fetch()){
		
		$temp = array();
		$temp['ID_Allarme']=$ID_Allarme;
		$temp['Data_Inizio']=$Data_Inizio;
		$temp['Data_Fine']=$Data_Fine;
		
		array_push($allarme, $temp);
	}
	
	echo json_encode($allarme);