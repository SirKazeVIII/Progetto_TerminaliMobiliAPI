package com.example.casadomoticatm;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomAdapterSM extends RecyclerView.Adapter<CustomAdapterSM.MyViewHolder> {

    Context context;
    LayoutInflater inflater;
    List<SensoriDiMonitoraggio> sensoriDiMonitoraggioList;
    String EliminaURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaEliminaSM.php";

    public CustomAdapterSM(Context context, List<SensoriDiMonitoraggio> sensoriDiMonitoraggioList) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.sensoriDiMonitoraggioList = sensoriDiMonitoraggioList;
    }


    @NonNull
    @Override
    public CustomAdapterSM.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.category_list_sm, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapterSM.MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.Nome_SM.setText(sensoriDiMonitoraggioList.get(position).getNome_sm());
        holder.Tipo_Consumo_SM.setText(sensoriDiMonitoraggioList.get(position).getTipo_consumo_sm());
        holder.Consumo_SM.setText(String.valueOf(sensoriDiMonitoraggioList.get(position).getConsumo_sm()));
        holder.Sensore_Attivabile.setText(sensoriDiMonitoraggioList.get(position).getSensore_attivabile());
        holder.AddOn_SM.setText(sensoriDiMonitoraggioList.get(position).getAddon_sm());

        holder.bottone_eliminaSM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminaSensoreSM(position);
                Intent intent = new Intent(context, ActivitySensoreDiMonitoraggio.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        holder.bottone_aggiungi_addonSM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AggiungiAddOnSM.class).putExtra("position", position);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sensoriDiMonitoraggioList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivabile, AddOn_SM;
        Button bottone_aggiungi_addonSM, bottone_eliminaSM;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Nome_SM = itemView.findViewById(R.id.Nome_SM);
            Tipo_Consumo_SM = itemView.findViewById(R.id.Tipo_Consumo_SM);
            Consumo_SM = itemView.findViewById(R.id.Consumo_SM);
            Sensore_Attivabile = itemView.findViewById(R.id.Sensore_Attivabile);
            AddOn_SM = itemView.findViewById(R.id.AddOn_SM);
            bottone_eliminaSM = itemView.findViewById(R.id.bottone_eliminaSM);
            bottone_aggiungi_addonSM = itemView.findViewById(R.id.bottone_aggiungi_addonSM);
        }
    }

    public void eliminaSensoreSM(int position) {
        StringRequest request = new StringRequest(Request.Method.POST, EliminaURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equalsIgnoreCase("Sensore Eliminato")) {
                    Toast.makeText(context, "Sensore Eliminato", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Nome_SM", sensoriDiMonitoraggioList.get(position).getNome_sm());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(request);
    }
}

