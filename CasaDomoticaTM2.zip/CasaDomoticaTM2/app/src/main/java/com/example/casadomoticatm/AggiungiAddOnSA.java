package com.example.casadomoticatm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AggiungiAddOnSA extends AppCompatActivity {

    String edNome;
    EditText edAddOn;
    private int position;
    String AggiornaURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaAddOnSA.php";
    Button bottoneAggiungi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aggiungi_add_on_sa);

        edAddOn = findViewById(R.id.add_addOn);

        Intent intent = getIntent();
        position = intent.getExtras().getInt("position");

        edAddOn.setText(ActivitySensoriAttivabili.sensoriAttivabiliList.get(position).getAddon_sa());
        edNome = ActivitySensoriAttivabili.sensoriAttivabiliList.get(position).getNome_sa();

        bottoneAggiungi = findViewById(R.id.buttonAggiungi);
        bottoneAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aggioranAddOnSA();
                Intent intent = new Intent(getApplicationContext(), ActivitySensoriAttivabili.class);
                startActivity(intent);
            }
        });
    }
        public void aggioranAddOnSA() {

            String nome = edNome;
            System.out.println(nome);
            String addon = edAddOn.getText().toString();
            System.out.println(addon);


            StringRequest request = new StringRequest(Request.Method.POST, AggiornaURL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(AggiungiAddOnSA.this, response, Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(AggiungiAddOnSA.this, "errore", Toast.LENGTH_SHORT).show();
                }
            }
            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Nome_SA", nome);
                    params.put("AddOn", addon);
                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(AggiungiAddOnSA.this);
            requestQueue.add(request);
        }
    }
