package com.example.casadomoticatm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;
import com.example.casadomoticatm.schermateAdd.AddSensoriMonitoraggio;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivitySensoreDiMonitoraggio extends AppCompatActivity {

    String URL_API = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaVisualizzaSM.php";
    public static List<SensoriDiMonitoraggio> sensoriDiMonitoraggioList;
    RecyclerView recyclerView;
    CustomAdapterSM customAdapterSM;
    FloatingActionButton addSensoriMonitoraggio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensore_di_monitoraggio);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.SensoriMonitoraggio);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.Home:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.SensoriAttivabili:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoriAttivabili.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.Allarmi:
                        startActivity(new Intent(getApplicationContext(), ActivityAllarme.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });


        sensoriDiMonitoraggioList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewcategorySM);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        caricaSensoriMonitoraggio();

        //Bottone che permette di accedere alla Activity AddSensoriMonitoraggio
        addSensoriMonitoraggio = findViewById(R.id.floatingActionButtonSM);
        addSensoriMonitoraggio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddSensoriMonitoraggio.class);
                startActivity(intent);
            }
        });


    }

    private void caricaSensoriMonitoraggio(){

        System.out.println("pippo");

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_API, response -> {
            try {
                JSONArray sensoriM = new JSONArray(response);

                for (int i=0; i< sensoriM.length(); i++){
                    JSONObject sensoriMonitoraggioObject = sensoriM.getJSONObject(i);

                    String Nome_SM = sensoriMonitoraggioObject.getString("Nome_SM");
                    String Tipo_Consumo_SM = sensoriMonitoraggioObject.getString("Tipo_Consumo_SM");
                    String Consumo_SM = sensoriMonitoraggioObject.getString("Consumo_SM");
                    String Sensore_Attivato = sensoriMonitoraggioObject.getString("Sensore_Attivato");
                    String AddOn = sensoriMonitoraggioObject.getString("AddOn");

                    System.out.println("ciao");
                    SensoriDiMonitoraggio sensoriDiMonitoraggio = new SensoriDiMonitoraggio(Nome_SM, Tipo_Consumo_SM, Consumo_SM, Sensore_Attivato, AddOn);
                    sensoriDiMonitoraggioList.add(sensoriDiMonitoraggio);
                    System.out.println(sensoriDiMonitoraggioList);
                }

                customAdapterSM = new CustomAdapterSM(ActivitySensoreDiMonitoraggio.this, sensoriDiMonitoraggioList);
                recyclerView.setAdapter(customAdapterSM);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ActivitySensoreDiMonitoraggio.this, "Errore", Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}