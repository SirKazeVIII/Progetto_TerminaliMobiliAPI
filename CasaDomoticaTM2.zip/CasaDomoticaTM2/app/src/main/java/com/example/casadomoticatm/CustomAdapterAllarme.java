package com.example.casadomoticatm;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.Allarme;
import com.example.casadomoticatm.category.SensoriAttivabili;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomAdapterAllarme extends RecyclerView.Adapter<CustomAdapterAllarme.MyViewHolder>{

    Context context;
    LayoutInflater inflater;
    List<Allarme> allarmeList;
    String EliminaURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaEliminaAllarme.php";

    public CustomAdapterAllarme(Context context, List<Allarme> allarmeList) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.allarmeList = allarmeList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.category_list_allarme, parent, false);
        return new CustomAdapterAllarme.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.ID_Allarme.setText(String.valueOf(allarmeList.get(position).getId_allarme()));
        holder.Data_Inizio.setText(String.valueOf(allarmeList.get(position).getData_inizio()));
        holder.Data_Fine.setText(String.valueOf(allarmeList.get(position).getData_fine()));

        holder.bottone_eliminaAllarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminaAllarme(position);
                Intent intent = new Intent(context, ActivityAllarme.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return allarmeList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ID_Allarme, Data_Inizio, Data_Fine;
        Button bottone_eliminaAllarme;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ID_Allarme = itemView.findViewById(R.id.ID);
            Data_Inizio = itemView.findViewById(R.id.Data_inizio);
            Data_Fine = itemView.findViewById(R.id.Data_fine);
            bottone_eliminaAllarme = itemView.findViewById(R.id.bottone_eliminaAllarme);
        }
    }

    public void eliminaAllarme(int position) {
        StringRequest request = new StringRequest(Request.Method.POST, EliminaURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equalsIgnoreCase("Allarme Eliminato")) {
                    Toast.makeText(context, "Allarme Eliminato", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("ID_Allarme", String.valueOf(allarmeList.get(position).getId_allarme()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(request);
    }
}
