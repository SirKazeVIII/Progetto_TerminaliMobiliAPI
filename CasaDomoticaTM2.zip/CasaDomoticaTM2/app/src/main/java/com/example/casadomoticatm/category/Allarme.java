package com.example.casadomoticatm.category;

import java.util.Date;

public class Allarme {

    int id_allarme;
    Date data_inizio;
    Date data_fine;

    public Allarme(int id_allarme, Date data_inizio, Date data_fine) {
        this.id_allarme = id_allarme;
        this.data_inizio = data_inizio;
        this.data_fine = data_fine;
    }

    public int getId_allarme() {
        return id_allarme;
    }

    public void setId_allarme(int id_allarme) {
        this.id_allarme = id_allarme;
    }

    public Date getData_inizio() {
        return data_inizio;
    }

    public void setData_inizio(Date data_inizio) {
        this.data_inizio = data_inizio;
    }

    public Date getData_fine() {
        return data_fine;
    }

    public void setData_fine(Date data_fine) {
        this.data_fine = data_fine;
    }

}
