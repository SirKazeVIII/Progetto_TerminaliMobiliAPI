package com.example.casadomoticatm;

import android.content.Context;

import com.example.casadomoticatm.category.SensoriAttivabili;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;

public class CodaRun implements Runnable {

    Context context;
    private Queue<Integer> coda = new ArrayDeque<Integer>();
    private volatile boolean exit = false;

    public CodaRun(Context context) {
        this.context = context;
    }

    public Queue<Integer> getCoda() {
        return this.coda;
    }

    @Override
    public void run() {

        //Gestione e creazione Coda
        coda = getCoda();
        System.out.println(coda);
        int j;
        int tempoAttivazioneConfronto = 0;
        String nomeConfronto = null;
        String nome = null;


        while (!exit) {

            if (ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList != null && ActivitySensoriAttivabili.sensoriAttivabiliList != null ) {

                //Tempo di attesa tra un errore e l'altro (Un minuto)
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("Mi stavo riposonado\n-----------------------------");

                //Numero randomico che utilizzo per creare allarmi sempre da sensori differenti
                int r = (int) (Math.random() * ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.size());
                System.out.println("RANDOM: " + r);
                int grandezzaSM = ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.size();
                System.out.println(grandezzaSM);
                //if per verificare che la mia random non sia piu grande del numero delle mie tuple
                if (r < ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.size()) {
                    System.out.println("Sto nel if\n-----------------------------");
                    nomeConfronto = (ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.get(r).getSensore_attivabile());
                    for (j = 0; j < ActivitySensoriAttivabili.sensoriAttivabiliList.size(); j++) {
                        nome = (ActivitySensoriAttivabili.sensoriAttivabiliList.get(j).getNome_sa());
                        if (nomeConfronto.equals(nome)) {
                            System.out.println("Sensore trovato Avvio Allarme" + "\n");
                            tempoAttivazioneConfronto = ActivitySensoriAttivabili.sensoriAttivabiliList.get(j).getTempo_attivazione();
                            System.out.println("Tempo Attivazione: " + tempoAttivazioneConfronto);
                            coda.add(tempoAttivazioneConfronto);
                            System.out.println(coda);
                            //Tempo di attesa tra un errore e l'altro (Un minuto)
                            try {
                                Thread.sleep(10000);
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        } else {
                            System.out.println("Errore Nessun Sensore Trovato");
                        }
                    }

                } else {
                    System.out.println("Errore");
                }
            }
            else {
                try {
                    Thread.sleep(10000);
                    System.out.println("Nessun Sensore Trovato\n-----------------------------");
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }
    //Metodo per fermare il while
    public void stop(){
        exit = true;
    }

    //Metodo per attivare il while
    public void play(){
        exit = false;
    }
}