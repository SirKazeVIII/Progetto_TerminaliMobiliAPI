package com.example.casadomoticatm.category;

public class SensoriDiMonitoraggio {

    String nome_sm;
    String tipo_consumo_sm;
    String consumo_sm;
    String sensore_attivabile;
    String addon_sm;


    public SensoriDiMonitoraggio (String nome_sm, String tipo_consumo_sm, String consumo_sm, String sensore_attivabile, String addon_sm) {
        this.nome_sm = nome_sm;
        this.tipo_consumo_sm = tipo_consumo_sm;
        this.consumo_sm = consumo_sm;
        this.sensore_attivabile = sensore_attivabile;
        this.addon_sm = addon_sm;
    }

    public SensoriDiMonitoraggio() {

    }

    public void setNome_sm(String nome_sm) {
        this.nome_sm = nome_sm;
    }

    public void setTipo_consumo_sm(String tipo_consumo_sm) {
        this.tipo_consumo_sm = tipo_consumo_sm;
    }

    public void setConsumo_sm(String consumo_sm) {
        this.consumo_sm = consumo_sm;
    }

    public void setSensore_attivabile(String sensore_attivabile) {
        this.sensore_attivabile = sensore_attivabile;
    }

    public void setAddon_sm(String addon_sm) {
        this.addon_sm = addon_sm;
    }

    public String getNome_sm() {
        return nome_sm;
    }

    public String getTipo_consumo_sm() {
        return tipo_consumo_sm;
    }

    public String getConsumo_sm() {
        return consumo_sm;
    }

    public String getSensore_attivabile() {
        return sensore_attivabile;
    }

    public String getAddon_sm() {
        return addon_sm;
    }
}
