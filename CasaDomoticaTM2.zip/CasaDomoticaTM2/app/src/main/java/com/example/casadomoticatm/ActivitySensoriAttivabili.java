package com.example.casadomoticatm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.SensoriAttivabili;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;
import com.example.casadomoticatm.schermateAdd.AddSensoriAttivabili;
import com.example.casadomoticatm.schermateAdd.AddSensoriMonitoraggio;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ActivitySensoriAttivabili extends AppCompatActivity {

    String URL_API = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaVisualizzaSA.php";
    public static List<SensoriAttivabili> sensoriAttivabiliList;
    RecyclerView recyclerView;
    CustomAdapterSA customAdapterSA;
    FloatingActionButton addSensoriAttivabili;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensori_attivabili);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.SensoriAttivabili);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.Home:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.SensoriMonitoraggio:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoreDiMonitoraggio.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.Allarmi:
                        startActivity(new Intent(getApplicationContext(), ActivityAllarme.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

        sensoriAttivabiliList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewcategorySA);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        caricaSensoriAttivabili();

        //Bottone che permette di accedere alla Activity AddSensoriMonitoraggio
        addSensoriAttivabili = findViewById(R.id.floatingActionButtonSA);
        addSensoriAttivabili.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddSensoriAttivabili.class);
                startActivity(intent);
            }
        });
    }

    private void caricaSensoriAttivabili(){

        System.out.println("pippo");

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_API, response -> {
            try {
                JSONArray sensoriA = new JSONArray(response);

                for (int i=0; i< sensoriA.length(); i++){
                    JSONObject sensoriAttivabiliObject = sensoriA.getJSONObject(i);

                    String Nome_SA = sensoriAttivabiliObject.getString("Nome_SA");
                    String Tipo_Consumo_SA = sensoriAttivabiliObject.getString("Tipo_Consumo_SA");
                    String Consumo_SA = sensoriAttivabiliObject.getString("Consumo_SA");
                    int Tempo_Attivazione = sensoriAttivabiliObject.getInt("Tempo_Attivazione");
                    String AddOn = sensoriAttivabiliObject.getString("AddOn");

                    System.out.println("ciao");
                    SensoriAttivabili sensoriAttivabili = new SensoriAttivabili(Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_Attivazione, AddOn);
                    sensoriAttivabiliList.add(sensoriAttivabili);
                    System.out.println(sensoriAttivabiliList);
                }

                customAdapterSA = new CustomAdapterSA(ActivitySensoriAttivabili.this, sensoriAttivabiliList);
                recyclerView.setAdapter(customAdapterSA);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ActivitySensoriAttivabili.this, "Errore", Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}