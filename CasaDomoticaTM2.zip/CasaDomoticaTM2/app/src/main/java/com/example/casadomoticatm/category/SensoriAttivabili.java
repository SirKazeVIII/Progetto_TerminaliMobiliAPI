package com.example.casadomoticatm.category;

public class SensoriAttivabili {

    String nome_sa;
    String tipo_consumo_sa;
    String consumo_sa;
    int tempo_attivazione;
    String addon_sa;

    public SensoriAttivabili(String nome_sa, String tipo_consumo_sa, String consumo_sa, int tempo_attivazione, String addon_sa) {
        this.nome_sa = nome_sa;
        this.tipo_consumo_sa = tipo_consumo_sa;
        this.consumo_sa = consumo_sa;
        this.tempo_attivazione = tempo_attivazione;
        this.addon_sa = addon_sa;
    }

    public String getNome_sa() {
        return nome_sa;
    }

    public void setNome_sa(String nome_sa) {
        this.nome_sa = nome_sa;
    }

    public String getTipo_consumo_sa() {
        return tipo_consumo_sa;
    }

    public void setTipo_consumo_sa(String tipo_consumo_sa) {
        this.tipo_consumo_sa = tipo_consumo_sa;
    }

    public String getConsumo_sa() {
        return consumo_sa;
    }

    public void setConsumo_sa(String consumo_sa) {
        this.consumo_sa = consumo_sa;
    }

    public int getTempo_attivazione() {
        return tempo_attivazione;
    }

    public void setTempo_attivazione(int tempo_attivazione) {
        this.tempo_attivazione = tempo_attivazione;
    }

    public String getAddon_sa() {
        return addon_sa;
    }

    public void setAddon_sa(String addon_sa) {
        this.addon_sa = addon_sa;
    }

}
