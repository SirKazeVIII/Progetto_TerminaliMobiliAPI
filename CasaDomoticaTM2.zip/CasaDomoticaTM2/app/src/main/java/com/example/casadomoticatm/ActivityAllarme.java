package com.example.casadomoticatm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.Allarme;
import com.google.android.material.bottomnavigation.BottomNavigationView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ActivityAllarme extends AppCompatActivity {

    String URL_API = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaVisualizzaAllarme.php";
    public static List<Allarme> allarmeList;
    RecyclerView recyclerView;
    CustomAdapterAllarme customAdapterAllarme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allarme);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.Allarmi);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.Home:
                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.SensoriAttivabili:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoriAttivabili.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.SensoriMonitoraggio:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoreDiMonitoraggio.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

        allarmeList = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerviewcategoryAllarme);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        caricaAllarmi();
    }
    private void caricaAllarmi(){
        System.out.println("pippo");

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_API, response -> {
            try {
                JSONArray allarmi = new JSONArray(response);

                for (int i=0; i< allarmi.length(); i++){
                    JSONObject allarmiObject = allarmi.getJSONObject(i);

                    int ID_Allarme = allarmiObject.getInt("ID_Allarme");
                    String dateInizioStr = allarmiObject.getString("Data_Inizio");
                    System.out.println(dateInizioStr);
                    String dateFineStr = allarmiObject.getString("Data_Fine");
                    System.out.println(dateFineStr);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date Data_Inizio = sdf.parse(dateInizioStr);
                    System.out.println(Data_Inizio);
                    Date Data_Fine = sdf.parse(dateFineStr);

                    System.out.println("ciao");
                    Allarme allarme = new Allarme (ID_Allarme, Data_Inizio, Data_Fine);
                    allarmeList.add(allarme);
                    System.out.println(allarmeList);
                }

                customAdapterAllarme = new CustomAdapterAllarme(ActivityAllarme.this, allarmeList);
                recyclerView.setAdapter(customAdapterAllarme);


            } catch (JSONException | ParseException e) {
                e.printStackTrace();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ActivityAllarme.this, "Errore", Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}