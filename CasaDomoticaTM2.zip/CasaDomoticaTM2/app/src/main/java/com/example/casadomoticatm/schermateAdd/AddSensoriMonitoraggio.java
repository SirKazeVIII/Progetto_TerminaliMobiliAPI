package com.example.casadomoticatm.schermateAdd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.ActivitySensoreDiMonitoraggio;
import com.example.casadomoticatm.R;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddSensoriMonitoraggio extends AppCompatActivity {

    EditText nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm;
    Button bottone_salva;
    String ServerURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaInserisciSM.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sensori_monitoraggio);

        nome_sm = findViewById(R.id.Nome_SM);
        tipo_consumo_sm = findViewById(R.id.Tipo_Consumo_SM);
        consumo_sm = findViewById(R.id.Consumo_SM);
        sensore_attivabile = findViewById(R.id.Sensore_Attivabile);
        addon_sm = findViewById(R.id.AddOn_SM);

        bottone_salva = findViewById(R.id.Salva_SM);
        bottone_salva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                inserisciSensore();
                Intent intent = new Intent(getApplicationContext(), ActivitySensoreDiMonitoraggio.class);
                startActivity(intent);
            }
        });
    }

    private void inserisciSensore() {

        String nome = nome_sm.getText().toString().trim();
        String tipo_consumo = tipo_consumo_sm.getText().toString().trim();
        String consumo = consumo_sm.getText().toString().trim();
        String sensoreAttivabile = sensore_attivabile.getText().toString().trim();
        String addon = addon_sm.getText().toString().trim();

        if (nome.isEmpty()){
            Toast.makeText(this, "Inserire Nome", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tipo_consumo.isEmpty()){
            Toast.makeText(this, "Inserire Tipo Consumo", Toast.LENGTH_SHORT).show();
            return;
        }
        if (consumo.isEmpty()){
            Toast.makeText(this, "Inserire Consumo", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            StringRequest request = new StringRequest(Request.Method.POST, ServerURL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    if (response.equalsIgnoreCase("Sensore Inserito")) {
                        Toast.makeText(AddSensoriMonitoraggio.this, "Sensore Inserito", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddSensoriMonitoraggio.this, response, Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(AddSensoriMonitoraggio.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        ){
                @Override
                protected Map <String,String> getParams() throws AuthFailureError{
                    Map<String,String> params = new HashMap<String,String>();
                    params.put("Nome_SM", nome);
                    params.put("Tipo_Consumo_SM", tipo_consumo);
                    params.put("Consumo_SM", consumo);
                    params.put("Sensore_Attivato", sensoreAttivabile);
                    params.put("AddOn", addon);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(AddSensoriMonitoraggio.this);
            requestQueue.add(request);
        }
    }
}