package com.example.casadomoticatm.schermateAdd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.ActivitySensoreDiMonitoraggio;
import com.example.casadomoticatm.ActivitySensoriAttivabili;
import com.example.casadomoticatm.R;

import java.util.HashMap;
import java.util.Map;

public class AddSensoriAttivabili extends AppCompatActivity {

    EditText nome_sa, tipo_consumo_sa, consumo_sa, tempo_attivazione_sa, addon_sa;
    Button bottone_salva;
    String ServerURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaInserisciSA.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sensori_attivabili);

        nome_sa = findViewById(R.id.Nome_SA);
        tipo_consumo_sa = findViewById(R.id.Tipo_Consumo_SA);
        consumo_sa = findViewById(R.id.Consumo_SA);
        tempo_attivazione_sa = findViewById(R.id.Tempo_Attivazione);
        addon_sa = findViewById(R.id.AddOn_SA);

        bottone_salva = findViewById(R.id.Salva_SA);
        bottone_salva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inserisciSensore();
                Intent intent = new Intent(getApplicationContext(), ActivitySensoriAttivabili.class);
                startActivity(intent);
            }
        });
    }

    private void inserisciSensore() {

        String nome = nome_sa.getText().toString().trim();
        String tipo_consumo = tipo_consumo_sa.getText().toString().trim();
        String consumo = consumo_sa.getText().toString().trim();
        String tempo_attivazione = tempo_attivazione_sa.getText().toString().trim();
        String addon = addon_sa.getText().toString().trim();

        if (nome.isEmpty()){
            Toast.makeText(this, "Inserire Nome", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tipo_consumo.isEmpty()){
            Toast.makeText(this, "Inserire Tipo Consumo", Toast.LENGTH_SHORT).show();
            return;
        }
        if (consumo.isEmpty()){
            Toast.makeText(this, "Inserire Consumo", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            StringRequest request = new StringRequest(Request.Method.POST, ServerURL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    if (response.equalsIgnoreCase("Sensore Inserito")) {
                        Toast.makeText(AddSensoriAttivabili.this, "Sensore Inserito", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddSensoriAttivabili.this, response, Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(AddSensoriAttivabili.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            ){
                @Override
                protected Map<String,String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String,String>();
                    params.put("Nome_SA", nome);
                    params.put("Tipo_Consumo_SA", tipo_consumo);
                    params.put("Consumo_SA", consumo);
                    params.put("Tempo_Attivazione", tempo_attivazione);
                    params.put("AddOn", addon);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(AddSensoriAttivabili.this);
            requestQueue.add(request);
        }
    }
}