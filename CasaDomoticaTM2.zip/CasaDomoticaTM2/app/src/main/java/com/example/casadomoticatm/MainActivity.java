package com.example.casadomoticatm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private Button bottone_attiva, bottone_disattiva;
    private int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.Home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.SensoriMonitoraggio:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoreDiMonitoraggio.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.SensoriAttivabili:
                        startActivity(new Intent(getApplicationContext(), ActivitySensoriAttivabili.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.Allarmi:
                        startActivity(new Intent(getApplicationContext(), ActivityAllarme.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });

        CodaRun codaRun = new CodaRun(MainActivity.this);
        Thread t = new Thread(codaRun);

        CreaRun creaRun = new CreaRun(MainActivity.this, codaRun);
        Thread z = new Thread(creaRun);

        i=0;

        //Bottone per avviare tutti i sensori
        bottone_attiva = findViewById(R.id.buttonAttiva);
        bottone_attiva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                if(i!=0){
                    //Toast.makeText(getContext(), "Sensori Attivati", Toast.LENGTH_SHORT).show();
                    codaRun.play();
                    creaRun.play();
                    return;
                }
                System.out.println("ciao");
                t.start();
                z.start();
                i=1;
                //Toast.makeText(getContext(), "Sensori Attivati", Toast.LENGTH_SHORT).show();
            }
        });

        //Bottone per disattivare tutti i sensori
        bottone_disattiva = findViewById(R.id.buttonDisattiva);
        bottone_disattiva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                codaRun.stop();
                creaRun.stop();;
                //Toast.makeText(getContext(), "Sensori Disattivati", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
