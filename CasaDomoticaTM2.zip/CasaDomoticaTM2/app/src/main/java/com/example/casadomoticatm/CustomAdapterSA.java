package com.example.casadomoticatm;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.SensoriAttivabili;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomAdapterSA extends RecyclerView.Adapter<CustomAdapterSA.MyViewHolder>{

    Context context;
    LayoutInflater inflater;
    List<SensoriAttivabili> sensoriAttivabiliList;
    String EliminaURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaEliminaSA.php";

    public CustomAdapterSA(Context context, List<SensoriAttivabili> sensoriAttivabiliList) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.sensoriAttivabiliList = sensoriAttivabiliList;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.category_list_sa, parent, false);
        return new CustomAdapterSA.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.Nome_SA.setText(sensoriAttivabiliList.get(position).getNome_sa());
        holder.Tipo_Consumo_SA.setText(sensoriAttivabiliList.get(position).getTipo_consumo_sa());
        holder.Consumo_SA.setText(String.valueOf(sensoriAttivabiliList.get(position).getConsumo_sa()));
        holder.Tempo_Attivazione.setText(String.valueOf(sensoriAttivabiliList.get(position).getTempo_attivazione()));
        holder.AddOn_SA.setText(sensoriAttivabiliList.get(position).getAddon_sa());

        holder.bottone_eliminaSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eliminaSensoreSA(position);
                Intent intent = new Intent(context, ActivitySensoriAttivabili.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
        holder.bottone_aggiungi_addonSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AggiungiAddOnSA.class).putExtra("position", position);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sensoriAttivabiliList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView Nome_SA, Tipo_Consumo_SA, Consumo_SA, Tempo_Attivazione, AddOn_SA;
        Button bottone_aggiungi_addonSA, bottone_eliminaSA;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Nome_SA = itemView.findViewById(R.id.Nome_sensore_SA);
            Tipo_Consumo_SA = itemView.findViewById(R.id.Tipo_Consumo_Sensore_SA);
            Consumo_SA = itemView.findViewById(R.id.Consumo_Sensore_SA);
            Tempo_Attivazione = itemView.findViewById(R.id.Tempo_Attivazione);
            AddOn_SA = itemView.findViewById(R.id.AddOn_Sensore_SA);
            bottone_eliminaSA = itemView.findViewById(R.id.bottone_eliminaSA);
            bottone_aggiungi_addonSA = itemView.findViewById(R.id.bottone_aggiungi_addonSA);
        }
    }

    public void eliminaSensoreSA(int position) {
        StringRequest request = new StringRequest(Request.Method.POST, EliminaURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equalsIgnoreCase("Sensore Eliminato")) {
                    Toast.makeText(context, "Sensore Eliminato", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
                }
            }
            }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Nome_SA", sensoriAttivabiliList.get(position).getNome_sa());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(request);
    }
}
