package com.example.casadomoticatm;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.category.SensoriDiMonitoraggio;

import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AggiungiAddOnSM extends AppCompatActivity {

    String edNome;
    EditText edAddOn;
    private int position;
    String AggiornaURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaAddOnSM.php";
    Button bottoneAggiungi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aggiungi_add_on_sm);

        edAddOn = findViewById(R.id.add_addOn);

        Intent intent = getIntent();
        position = intent.getExtras().getInt("position");

        edAddOn.setText(ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.get(position).getAddon_sm());
        edNome = ActivitySensoreDiMonitoraggio.sensoriDiMonitoraggioList.get(position).getNome_sm();

        bottoneAggiungi = findViewById(R.id.buttonAggiungi);
        bottoneAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aggioranAddOnSM();
                Intent intent = new Intent(getApplicationContext(), ActivitySensoreDiMonitoraggio.class);
                startActivity(intent);
            }
        });
    }

    public void aggioranAddOnSM() {

        String nome = edNome;
        System.out.println(nome);
        String addon = edAddOn.getText().toString();
        System.out.println(addon);


        StringRequest request = new StringRequest(Request.Method.POST, AggiornaURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(AggiungiAddOnSM.this, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(AggiungiAddOnSM.this, "errore", Toast.LENGTH_SHORT).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Nome_SM", nome);
                params.put("AddOn", addon);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(AggiungiAddOnSM.this);
        requestQueue.add(request);
    }
}
