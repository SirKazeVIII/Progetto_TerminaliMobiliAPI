package com.example.casadomoticatm;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.casadomoticatm.schermateAdd.AddSensoriMonitoraggio;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

public class CreaRun implements Runnable  {

    String ServerURL = "http://192.168.56.1/ApiCasaDomotica/APICasaDomoticaInserisciAllarme.php";

    private final Context context;
    CodaRun cr;
    private volatile boolean exit = false;

    public CreaRun(Context context, CodaRun cr) {
        this.context = context;
        this.cr = cr;
    }

    @Override
    public void run() {
        Queue<Integer> coda = cr.getCoda();
        int temp;


        //While per la gestione dell'autoattivazione
        while (!exit) {
            System.out.println("Sto in CreaRun");

            //If che controlla se la coda è vuota. Se la coda è vuota aspetta un minuto.
            if(coda.isEmpty()) {
                try {
                    Thread.sleep(60000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("La coda è vuota");
            }

            //Else che gestisce il poll dalla queue e che moltiplica il tempo di attivazione * un minuto
            else {
                temp = coda.poll();
                System.out.println(coda + "\n-----------------------------");
                temp = temp * 60000;
                System.out.println(temp + "\n-----------------------------");
                try {
                    Thread.sleep(temp);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                //Salvataggio nel DB dell'allarme
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date d = new Date();
                Calendar cal = Calendar.getInstance();
                cal.setTime(d);
                int minuti = temp/60000;
                cal.add(Calendar.MINUTE, -minuti);
                System.out.println("cal =" +cal);
                Date d1 = cal.getTime();
                String fine = dateFormat.format(d);
                System.out.println(fine + "\n-----------------------------");
                String inizio = dateFormat.format(d1);
                System.out.println(inizio + "\n-----------------------------");

                //Salvataggio
                StringRequest request = new StringRequest(Request.Method.POST, ServerURL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.equalsIgnoreCase("Sensore Inserito")) {
                            //Toast.makeText(context, "Sensore Inserito", Toast.LENGTH_SHORT).show();
                        } else {
                            //Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                ){
                    @Override
                    protected Map<String,String> getParams() throws AuthFailureError {
                        Map<String,String> params = new HashMap<String,String>();
                        params.put("Data_Inizio", inizio);
                        params.put("Data_Fine", fine);
                        return params;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(context);
                requestQueue.add(request);
            }

        }
    }
    //Metodo per fermare il while
    public void stop(){
        exit = true;
    }

    //Metodo per attivare il while
    public void play(){
        exit = false;
    }
}

